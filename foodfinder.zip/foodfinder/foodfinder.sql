-- MySQL dump 10.13  Distrib 5.6.35, for osx10.9 (x86_64)
--
-- Host: localhost    Database: foodfinder
-- ------------------------------------------------------
-- Server version	5.6.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `message` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rest_ID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rest_ID` (`rest_ID`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `contact_ibfk_1` FOREIGN KEY (`rest_ID`) REFERENCES `restaurant` (`rest_ID`),
  CONSTRAINT `contact_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,'Test','krupahp90@gmail.com','Invitation to Grazie Italiano','success','2017-12-15 16:16:11',24,31),(2,'test','krupahp90@gmail.com','chik-fil-A','hello an invitation to chik-fil-A','2017-12-15 16:19:44',19,26),(3,'hasika','krupahp90@gmail.com','chik-fil-A','hello an invitation to chik-fil-A','2017-12-15 16:21:05',19,26),(4,'John','kruhpate@iu.edu','Rush Hour Station','Invitation to RUSH HOUR.','2017-12-15 16:23:53',36,32),(5,'Test','web-ww8rr@mail-tester.com','test','test','2017-12-15 16:39:11',29,31);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant` (
  `rest_ID` int(11) NOT NULL AUTO_INCREMENT,
  `rest_Name` varchar(100) DEFAULT NULL,
  `rest_ShopNo` varchar(50) DEFAULT NULL,
  `rest_Street` varchar(100) DEFAULT NULL,
  `rest_City` varchar(100) DEFAULT NULL,
  `rest_State` varchar(100) DEFAULT NULL,
  `rest_zip` varchar(40) DEFAULT NULL,
  `rest_Phone` varchar(15) DEFAULT NULL,
  `rest_Description` varchar(400) DEFAULT NULL,
  `open_Time` varchar(20) DEFAULT NULL,
  `close_Time` varchar(20) DEFAULT NULL,
  `rest_URL` varchar(200) DEFAULT NULL,
  `cuisine` varchar(100) DEFAULT NULL,
  `rest_map` varchar(1000) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`rest_ID`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `restaurant_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` VALUES (18,'Amrit India','124','N Walnut Street','Bloomington','Indiana','47404','8126503812','Family-owned, offering regional specialities, spicy, mild curries and more.','11:00 a.m','9:45 p.m','amritindiarestaurant.com','Indian traditional','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.3215851650307!2d-86.53555988464164!3d39.16740937952992!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66ddb774ff59%3A0xe51b9b7357c0892!2sThe+Amrit+India!5e0!3m2!1sen!2sus!4v1513314208081',20),(19,' chick-fil-A','3020','E 3rd Street','Bloomington','Indiana','47401','8123305590','Fast-food chain serving chicken sandwiches, strips & nuggets along with salads & side','6:30 a.m.','11:00 p.m.','www.chik-fil-a.com','fast food cuisine','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d49494.653108316765!2d-86.56533550070174!3d39.16526671863316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c64220763242f%3A0x96fb49624cf7711c!2sChick-fil-A!5e0!3m2!1sen!2sus!4v1513208354748',27),(24,'Grazie Italiano','106','W 6th Street','Bloomington','Indiana','47404','8123230303','Lively restaurant & lounge serving traditional & modern Italian plates, plus happy hour & brunch.','11:30 ','9:30 p.m','grazieitaliano.com','Italian food','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.3076035725253!2d-86.53608698482219!3d39.167727279529764!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66ddcbcef55d%3A0x42686964c1a69da7!2sGrazie+Italiano!5e0!3m2!1sen!2sus!4v1513208578793',30),(27,'Asuka Japanese Restaurant ','318','S.College Mall Rd','Bloomington','Indiana','47408','8123338325','Hibachi grill with authentic japanese food and sushi','11:00 a.m','10:00 p.m.','asukajapanesecuisine.com','japanese','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.4952981797924!2d-86.50138918482233!3d39.16345947953042!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c6420222a1903%3A0xbfcfe395bc8ca101!2sAsuka+Japanese+Steakhouse+%26+Sushi!5e0!3m2!1sen!2sus!4v1513210245724',20),(28,'Burma Garden','413','E 4th Street','Bloomington','Indiana','47408','8123397334','Authentic Burmese cuisine with other asian influences.','11:30 a.m','9:30 p.m','burmagarden.com','burmese cuisine','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.394917695853!2d-86.53129068482221!3d39.16574197953016!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66c2a94cdbe3%3A0x2f702d63577af9d6!2sBurma+Garden+Restaurant+(Mandalay)!5e0!3m2!1sen!2sus!4v1513210305574',20),(29,'China Star','4641','W Richland Plaza Dr','Bloomington','Indiana','47404','8128765778','Great food, great prices, great service','11:00 a.m','9:30 p.m','notapplicable','chinese','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3091.114883418095!2d-86.59644708482058!3d39.21755647952255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c67f54e9cc55f%3A0xd33865a59adf68ec!2sChina+Star+Restaurant!5e0!3m2!1sen!2sus!4v1513210344546',27),(30,'El ranchero ','3615 ','W SR 46','Bloomington','Indiana','47401','8128222329','Mexican restaurant with full bar, welcomes large parties.','10:00 a.m','9:30 p.m','elrancherofood.com','Mexican','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3091.4775908994934!2d-86.58681718482087!3d39.20931767952373!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c5e1ec750c465%3A0xdb73ca9625b0cec1!2sEl+Ranchero+Mexican+Restaurant!5e0!3m2!1sen!2sus!4v1513210402518',27),(31,'Fortune Cookies','1809','E 10th Street','Bloomington','Indiana','47404','8128222828','Chinese food with contemporary atmosphere and bubble tea','11:00 a.m','11:00 p.m.','fortunecookiesbloomington.net','chinese','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.1342133577045!2d-86.51303218482208!3d39.17166947952924!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66bb16503b37%3A0xadef3f6fc5a9b91b!2sFortune+Cookies!5e0!3m2!1sen!2sus!4v1513210449111',27),(32,'Gimmie sum moe','108','S. Rogers Street','Bloomington','Indiana','47404','2197073455','Tacos, burritos, Korean BBQ, and bacon jam','11:00 a.m','10:00 p.m.','facebook.com/gimmiesummoe','mexican','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.3749509594863!2d-86.54112968482222!3d39.16619597952999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66dfe878d7bb%3A0x5cfce482fa187570!2sGimme+Some+Moe!5e0!3m2!1sen!2sus!4v1513210486986',27),(33,'Le Petit Cafe','308','W 6th Street','Bloomington','Indiana','47404','8123349747','French cuisine with a home setting','5:30 p.m','9:00 p.m','lpc1977.com','French','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.3068690854716!2d-86.53877768482215!3d39.167743979529945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66de50888cc3%3A0x9f2846cd03dbce99!2sLe+Petit+Cafe!5e0!3m2!1sen!2sus!4v1513210532102',27),(34,'Red Chopsticks','1420','E 3rd Street','Bloomington','Indiana','47404','8123316898','Offering Japanese food, sushi and sashimi.','11:00 a.m','10:00 p.m.','redchopsticksin.com','japanese','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.469219516245!2d-86.51799908482229!3d39.164052479530426!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66958d687acf%3A0x20266302ee4f6141!2sRed+Chopsticks!5e0!3m2!1sen!2sus!4v1513210585562',27),(35,'Soban','1811','E 10th Street','Bloomington','Indiana','47404','8123331004','Authentic korean cuisine','11:00 a.m','9:00 p.m','iujaponee.com','korean','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.122715655167!2d-86.51239468482208!3d39.17193087952925!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66bb30bf9e71%3A0x498f96918dd23acb!2sSobon!5e0!3m2!1sen!2sus!4v1513210645883',27),(36,'Rush Hour Station','421','E 3rd Street','Bloomington','Indiana','47401','8123237874','Asian-style sandwiches, dumplings, fusion burritos, curry and more','11:00 a.m','9:00 p.m','rushhourstation.com','asian','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.4326736477333!2d-86.53077458482227!3d39.164883479530246!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66e8222f5675%3A0x12b7851b877f337d!2sRush+Hour+Station!5e0!3m2!1sen!2sus!4v1513210691804',27),(37,'Papa John\'s Pizza','2486','S Walnut Street','Bloomington','Indiana','47404','8123537272','Nice pizza place','11:00 a.m','10:00 p.m.','papajohns.com','pizza','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3094.6698619377867!2d-86.53463968482325!3d39.13674337953432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c665066afb52f%3A0x54ddcb53f1dc2679!2sPapa+John&#39;s+Pizza!5e0!3m2!1sen!2sus!4v1513210845274',20),(38,'PizzaHut','250','S Pete Ellis Dr','Bloomington','Indiana','47401','8123341662','Family-friendly chain known for its made-to-order pizzas.','10:00 a.m','10:00 p.m.','www.pizzahut.com','pizza','https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d24753.28715267647!2d-86.49324593205398!3d39.14832201259881!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c641eb66febc3%3A0xb6472164360787c2!2sPizza+Hut!5e0!3m2!1sen!2sus!4v1513207996490',20),(39,'Subway','200','N Walnut Street','Bloomington','Indiana','47404','8123397827','Casual counter-serve chain for build-your-own sandwiches & salads.','8:00 a.m.','10:00 p.m.','subway.com','Sandwich  ','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d49514.7214898772!2d-86.56747050094029!3d39.13673811972185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66ddb68bad01%3A0x9a92d5d3cba5a0c9!2sSUBWAY%C2%AERestaurants!5e0!3m2!1sen!2sus!4v1513210935545',27),(41,'Starbucks','110 ','S Indiana Ave','Bloomington','Indiana','47408','8123336075','Seattle-based coffeehouse chain known for its signature roasts, light bites and WiFi availability.','6:00 a.m.','12:00 a.m.','starbucks.com','cafe','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.37810870736!2d-86.52925238482223!3d39.16612417953017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66c26415c0fd%3A0x3d03471f237dc5a5!2sStarbucks!5e0!3m2!1sen!2sus!4v1513210993881',30),(42,'Subway','3313','West State Rd','Bloomington','Indiana','47403','8123331399','Casual counter serve chain for build your own sandwiches','7:00 a.m','9:00 p.m.','subway.com','fast food sandwiches','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12377.852787468346!2d-86.58883133022458!3d39.14144519999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c678035de3719%3A0x7e1fd59c3e36876f!2sSUBWAY%C2%AERestaurants!5e0!3m2!1sen!2sus!4v1513211100104',27),(43,'Chipotle Mexican Grill','2894','E 3rd Street','Bloomington','Indiana','47401','8123347623','Fast-food chain offering Mexican fare, including design-your-own burritos, tacos & bowls.','10:45 a.m','10:00 p.m.','chipotle.com','mexican','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.585867288113!2d-86.49878568482238!3d39.16139997953073!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886dbe9644eb20bb%3A0x2a7576d82141f224!2sChipotle+Mexican+Grill!5e0!3m2!1sen!2sus!4v1513216426770',20),(44,'Dominos Pizza','2620','S Walnut Street','Bloomington','Indiana','47403','8123357777','chain offering a wide range of pizza, plus chicken & other sides','11:00 a.m','1:00 a.m','dominos.com','pizza','https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d99013.17625433976!2d-86.54577631288412!3d39.14830236279253!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c665ada0110db%3A0x6c527b2cb9b96594!2sDomino&#39;s+Pizza!5e0!3m2!1sen!2sus!4v1513219104021',30),(45,'KFC','2901','E 3rd Street','Bloomington','Indiana','47401','8123341095','Fast-food chain known for its buckets of fried chicken, plus wings & sides.','10:00 a.m','11:00 p.m','kfc.com','fast food','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d197989.76099984374!2d-86.63668198722374!3d39.16130564613042!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c641f558a2f05%3A0x5826724e896fd6d0!2sKFC!5e0!3m2!1sen!2sus!4v1513219517969',27),(46,'Mother Bear\'s Pizza','1428','E 3rd Street','Bloomington','Indiana','47401','8123331399','Deep-dish pizzas & American snacks, plus beer & wine, at a local landmark resembling a rustic cabin.','11:00 a.m','10:00 p.m.','motherbearspizza.com','pizza','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.4679793421965!2d-86.51774688482233!3d39.16408067953043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c6695f2b293cb%3A0xd1e30fafa812b56b!2sMother+Bear&#39;s+Pizza+Campus!5e0!3m2!1sen!2sus!4v1513220350358',27),(47,'Irish Lion','212','W Kirkwood Ave','Bloomington','Indiana','47404','8123369076','Vintage decor sets a cozy yet busy stage for Irish-American pub grub paired with pints & scotch.','11:00 a.m','12:00 a.m','irishlion.com','irish','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.352653074996!2d-86.53773968464169!3d39.16670297952994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66de0a9bc6e9%3A0x9e93e061dc39ee16!2sThe+Irish+Lion+Restaurant+%26+Pub!5e0!3m2!1sen!2sus!4v1513227552378',30),(48,'Panera Bread','2748','E 3rd Street','Bloomington','Indiana','47401','8123359785','Counter-serve bakery/cafe chain serving sandwiches, salads & more, known for its bread & free WiFi.','6:00 a.m.','10:00 p.m.','panerabread.com','Sandwich  ','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.4936710216084!2d-86.50114428448789!3d39.1634964795304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c64202232ed75%3A0xb6165538440d28dc!2sPanera+Bread!5e0!3m2!1sen!2sus!4v1513227974827',27),(49,'Farm Bloomington','108','E Kirkwood Ave.','Bloomington','Indiana','47404','8123230002','All-day cafe with a funky vintage vibe, modern farmhouse-inspired cuisine & downstairs nightclub.','7:00 a.m','10:00 p.m.','farm-bloomington.com','american','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.37093559895!2d-86.53522968464168!3d39.16628727953017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886c66dd964bcf01%3A0x11a4f6408a9f0d71!2sFARMbloomington!5e0!3m2!1sen!2sus!4v1513298455057',20);
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `review_no` int(100) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) NOT NULL,
  `review_subject` varchar(200) NOT NULL,
  `review_email` varchar(100) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `rest_ID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`review_no`),
  KEY `user_id` (`user_id`),
  KEY `rest_ID` (`rest_ID`),
  CONSTRAINT `review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `review_ibfk_2` FOREIGN KEY (`rest_ID`) REFERENCES `restaurant` (`rest_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (31,'krupa','Amrit India','krupahp90@gmail.com','Hi, The food here available is traditionally indian style.','2011-12-13',18,20),(35,'jenny',' chick-fil-A','jenny@gmail.com','The food could have used more seasoning or more flavor all around.','2017-11-03',19,27),(48,'Vraj','Grazie Italiano','vraj@gmail.com','It is nice restaurant and service was too good.','2017-12-01',24,30),(49,'test','El ranchero ','test@gmail.com','Service was prompt, and friendly. Our dishes (Burrito El Ranchero and Chicken Quesadilla) were very flavorful!','2016-12-08',30,31),(50,'hasika','Burma Garden','hasika@gmail.com','The fried catfish is the best food in town','2017-02-26',28,26),(51,'hasika','El ranchero ','hasika@gmail.com','Prompt service, good food, reasonable prices, and nice atmosphere','2017-10-04',30,26),(52,'krupa','Subway','krupahp90@gmail.com','They made my day and treated their employees with the most compassion','2017-01-16',39,20),(53,'Vraj','PizzaHut','vraj@gmail.com','It is nice fast food service.','2017-05-19',38,30),(54,'hello','El ranchero ','hello@gmail.com','Nice mexican restaurant','2017-07-08',30,29),(55,'hello','Rush Hour Station','hello@gmail.com','Nice asian style recipes satisfying asian taste.','2017-12-05',36,29),(56,'hello','Le Petit Cafe','hello@gmail.com','Good place to have french cuisine.','2017-12-15',33,29);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_fname` varchar(150) NOT NULL,
  `user_lname` varchar(150) NOT NULL,
  `dob` date NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (20,'krupahp90@gmail.com','krupa','Patel','1990-02-04','krupa','admin'),(26,'hasika@gmail.com','hasika','mahtta','1978-10-19','hasika','user'),(27,'jenny@gmail.com','jenny','patel','1999-02-07','patel','admin'),(29,'hello@gmail.com','hello','world','1991-11-26','hello','user'),(30,'vraj@gmail.com','Vraj','patel','2001-10-27','vraj','admin'),(31,'test@gmail.com','test','test','2017-12-30','test','user'),(32,'john@gmail.com','John','Smith','1984-08-27','john','user');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-15 12:52:03
